import csv
import time
from pyecharts.charts import Bar
from pyecharts import options as opts
def bar1(data,barname,title):
    name=[]
    num = []
    for i in range (len(data)):
        name.append(data[i][0])
    for i in range(len(data)):
        num.append(data[i][1])
    # print(num)
    bar = (
        Bar()
    .add_xaxis(name)
    .add_yaxis("国家",num)
    .set_global_opts(title_opts=opts.TitleOpts(title=title),
    datazoom_opts = opts.DataZoomOpts(),
                     )
    )
    bar.render("排序柱状图\\"+barname+".html")
def bubble_sort(array):
    for i in range(1, len(array)):
        for j in range(0, len(array)-i):
            if array[j][1] < array[j+1][1]:
                array[j][0], array[j+1][0] = array[j+1][0], array[j][0]
                array[j][1], array[j+1][1] = array[j+1][1], array[j][1]
    return array
def oversea():
    file_name = '全世界' + '_' + time.strftime('%Y年%m月%d日', time.localtime(time.time())) + '.csv'
    open('每日疫情报告/' + file_name, 'r', encoding="utf-8")
    with open('每日疫情报告/'+file_name,'r',encoding="utf-8") as csvfile:
        reader = csv.reader(csvfile)
        name= [row[2] for row in reader]
    with open('每日疫情报告/'+file_name,'r',encoding="utf-8") as csvfile:
        reader = csv.reader(csvfile)
        confirm= [row[9] for row in reader]
    del(name[0])
    del(confirm[0])
    data=[[0]*2 for i in range(len(name))]
    for i in range (len(confirm)):
        if confirm[i].strip()=='':
            confirm[i]="0"
    confirm=list(map(float,confirm))
    confirm = list(map(int, confirm))
    for i in range (len(name)):
        data[i][0] =name[i]
        data[i][1]=(confirm[i])
    sort=bubble_sort(data)
    bar1(sort,"全球","全球现存新冠病例")
def china():
    file_name = '中国各省份' + '_' + time.strftime('%Y年%m月%d日', time.localtime(time.time())) + '.csv'
    open('每日疫情报告/' + file_name, 'r', encoding="utf-8")
    with open('每日疫情报告/'+file_name,'r',encoding="utf-8") as csvfile:
        reader = csv.reader(csvfile)
        name= [row[2] for row in reader]
    with open('每日疫情报告/'+file_name,'r',encoding="utf-8") as csvfile:
        reader = csv.reader(csvfile)
        confirm= [row[12] for row in reader]
    del(name[0])
    del(confirm[0])
    data=[[0]*2 for i in range(len(name))]
    for i in range (len(confirm)):
        if confirm[i].strip()=='':
            confirm[i]="0"
    confirm=list(map(float,confirm))
    confirm = list(map(int, confirm))
    for i in range (len(name)):
        data[i][0] =name[i]
        data[i][1]=(confirm[i])
    sort=bubble_sort(data)
    bar1(sort,"全国","全国现存新冠病例")
