# 将自己需要的数据提取下来
def save_to_excel(data_1: dict, data_2: dict, filename):
    wb = Workbook()
    wb.remove(wb.active)
    worksheet_1 = wb.create_sheet("新增本土病例")
    worksheet_2 = wb.create_sheet("新增无症状感染病例")
    excel_write(worksheet_1, data_1)
    excel_write(worksheet_2, data_2)
    wb.save(f'C:/Users/娃哈哈小可爱/Desktop/spider/{filename}.xlsx')