# 爬取数据
import time
import os
import asyncio
from lxml import etree
from pyppeteer import launch

# 用来绕过浏览器检测
async def pyppeteer_fetch_url(url):
    browser = await launch({'headless': True, 'dump': True, 'autoClose': True})
    page = await browser.newPage()
    await page.evaluateOnNewDocument('() =>{ Object.defineProperties(navigator,'
                                     '{ webdriver:{ get: () => false } }) }')
    await page.setUserAgent(
        'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (HTML, like Gecko) Chrome/105.0.0.0 Mobile Safari/537.36 Edg/105.0.1343.27')
    await page.goto(url)
    await asyncio.wait([page.waitForNavigation()])
    str = await page.content()
    await browser.close()
    return str


# 获取卫健委疫情通报版面每一页的url
def get_page_url():
    url_list = []
    for page in range(1, 42):        # 目前有42页
        if page == 1:
            url_list.append('http://www.nhc.gov.cn/xcs/yqtb/list_gzbd.shtml')
        else:
            page_url = 'http://www.nhc.gov.cn/xcs/yqtb/list_gzbd_' + str(page) +'.shtml'
            url_list.append(page_url)
    return url_list             # 返回一个链表


# 获取疫情通报版面/具体疫情通报的html
def get_page_html(url):
    return asyncio.get_event_loop().run_until_complete(pyppeteer_fetch_url(url))


# 获取每一条疫情通报的标题作为文件名
def get_files_name(html):
    files_name_list =[]
    html_tree = etree.HTML(html)
    li_list = html_tree.xpath("/html/body/div[3]/div[2]/ul/li")      # 利用xpath
    for li in li_list:
        file = li.xpath("./a/text()")
        file = "".join(file)
        file_name = file
        files_name_list.append(file_name)
    return files_name_list         # 返回文件名列表

# 获取疫情通报版面的每页具体的每一条通报的url
def get_news_url(html):
    news_url_list = []
    html_tree = etree.HTML(html)
    li_list = html_tree.xpath("/html/body/div[3]/div[2]/ul/li")     # 利用xpath
    for li in li_list:
        news_url = li.xpath('./a/@href')
        news_url = "http://www.nhc.gov.cn" + "".join(news_url[0])
        news_url_list.append(news_url)
    return news_url_list           # 返回每页url列表

# 获取所需要的关于疫情的信息
def get_key_info(html):
    html_tree = etree.HTML(html)
    text = html_tree.xpath('/html/body/div[3]/div[2]/div[3]//text()')
    news_text = "   ".join(text)
    return news_text

# 将爬到的数据保存到文件中
def save_as_file(path, files_name, key_info):
    if not os.path.exists(path):
        os.makedirs(path)
    with open(path + files_name + ".txt", 'w', encoding='utf-8') as f:
        f.write(key_info)


if "__main__" == __name__:
    for url in get_page_url():
        page_html = get_page_html(url)
        time.sleep(1)               # 延迟时间1s，简单反爬
        files_name = get_files_name(page_html)
        i = 0
        news_url = get_news_url(page_html)
        for a in news_url:
            html = get_page_html(a)
            key_info = get_key_info(html)
            print(files_name[i] + "爬取成功！")
            save_as_file('C:/Users/娃哈哈小可爱/Desktop/spider/', files_name[i], key_info)
            i += 1
    print("爬完啦爬完啦!")
