from process import process_work
from crawler import crawler_work

if "__main__" == __name__:
    crawler_work()
    process_work()
