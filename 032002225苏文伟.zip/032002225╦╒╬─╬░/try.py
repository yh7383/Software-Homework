import time
import re
import asyncio
from pyppeteer import launcher #通过pyppeteer来躲避反爬虫机制
launcher.DEFAULT_ARGS.remove("--enable-automation")
#把--enable-automation禁用，防止检测webdrive  ps:(launcher.AUTOMATION_ARGS.remove("--enable-automation")会报错)
from pyppeteer import launch
import xlwt
from bs4 import BeautifulSoup

'''
第一页：http://www.nhc.gov.cn/xcs/yqtb/list_gzbd.shtml
else第n页：http://www.nhc.gov.cn/xcs/yqtb/list_gzbd_{0}.shtml.format(str(page))
'''
async def pyppteer_fetchUrl(url): #await得在async里面

    browser = await launch({'headless': False,'dumpio':True, 'autoClose':True})
    page = await browser.newPage()
    await page.goto(url)
    await asyncio.wait([page.waitForNavigation()]) #等到爬取完才跳到下一页
    str = await page.content()
    await browser.close()
    return str

def spider(page):

    base_url = "http://www.nhc.gov.cn"
    if i == 1:
        url = 'http://www.nhc.gov.cn/xcs/yqtb/list_gzbd.shtml'
    else:
        url = 'http://www.nhc.gov.cn/xcs/yqtb/list_gzbd_{0}.shtml'.format(str(page))

    data = asyncio.get_event_loop().run_until_complete(pyppteer_fetchUrl(url)) #获取了网页源码
    data_soup = BeautifulSoup(data,'lxml') #解析页面
    list = data_soup.find('div', attrs = {"class":"list"}).find_all("li")

    global num #全局变量
    for item in list:
        data_url = base_url + item.a["href"] #第二层
        title = item.a["title"] # 标题
        data = asyncio.get_event_loop().run_until_complete(pyppteer_fetchUrl(data_url))  # 获取了第二层网页源码html

        try:
            bsobj = BeautifulSoup(data, 'html.parser')
            cnt = bsobj.find('div', attrs = {"id": "xw_box"}).find_all("p")
            s = ""
            if cnt:
                for item in cnt:
                    s += item.text #文本内容
            t1 = re.findall(r"31个省（自治区、直辖市）和新疆生产建设兵团报告新增确诊病例.+?）。",s,re.S)[0] #截取第一自然段新感染
            t2 = re.findall(r"31个省（自治区、直辖市）和新疆生产建设兵团报告新增无症状感染者.+?）。",s,re.S)[0]  #截取无症状感染者那一段

            co1 = r"本土病例.+?），含" #新增确诊病例
            co11 = r"本土病例.+?）。"
            co2 = r"本土.+?）。" #无症状感染者
            co3 = r"其中，香港特别行政区.+?）。" #港澳台地区

            try:
                context1 = re.findall(co1, t1, re.S)[0] #截取的本土
            except:
                context1 = re.findall(co11, t1, re.S)[0] #特殊情况之一，例：2022年6月25
            context2 = re.findall(co2, t2, re.S)[0] #截取的无症状
            context3 = re.findall(co3, s, re.S)[0] #截取的港澳台

            num += 1
            print("第{0}篇文章已爬取完成".format(num)) #标志，看爬到几篇了
            # 下面就是对着xls写入
            sheet.write(num, 0, title)
            sheet.write(num, 1, re.findall(r"本土病例(.+?)例",context1))
            sheet.write(num, 2, re.findall(r"本土(.+?)例", context2))
            sheet.write(num, 3, re.findall(r"西藏(.+?)例",context1))
            sheet.write(num, 4, re.findall(r"西藏(.+?)例", context2))
            sheet.write(num, 5, re.findall(r"贵州(.+?)例", context1))
            sheet.write(num, 6, re.findall(r"贵州(.+?)例", context2))
            sheet.write(num, 7, re.findall(r"黑龙江(.+?)例", context1))
            sheet.write(num, 8, re.findall(r"黑龙江(.+?)例", context2))
            sheet.write(num, 9, re.findall(r"福建(.+?)例", context1))
            sheet.write(num, 10, re.findall(r"福建(.+?)例", context2))
            sheet.write(num, 11, re.findall(r"四川(.+?)例", context1))
            sheet.write(num, 12, re.findall(r"四川(.+?)例", context2))
            sheet.write(num, 13, re.findall(r"江西(.+?)例", context1))
            sheet.write(num, 14, re.findall(r"江西(.+?)例", context2))

            sheet.write(num, 15, re.findall(r"湖北(.+?)例", context1))
            sheet.write(num, 16, re.findall(r"湖北(.+?)例", context2))
            sheet.write(num, 17, re.findall(r"陕西(.+?)例", context1))
            sheet.write(num, 18, re.findall(r"陕西(.+?)例", context2))
            sheet.write(num, 19, re.findall(r"辽宁(.+?)例", context1))
            sheet.write(num, 20, re.findall(r"辽宁(.+?)例", context2))
            sheet.write(num, 21, re.findall(r"山东(.+?)例", context1))
            sheet.write(num, 22, re.findall(r"山东(.+?)例", context2))
            sheet.write(num, 23, re.findall(r"广西(.+?)例", context1))
            sheet.write(num, 24, re.findall(r"广西(.+?)例", context2))
            sheet.write(num, 25, re.findall(r"新疆(.+?)例", context1))
            sheet.write(num, 26, re.findall(r"新疆(.+?)例", context2))

            sheet.write(num, 27, re.findall(r"甘肃(.+?)例", context1))
            sheet.write(num, 28, re.findall(r"甘肃(.+?)例", context2))
            sheet.write(num, 29, re.findall(r"内蒙古(.+?)例", context1))
            sheet.write(num, 30, re.findall(r"内蒙古(.+?)例", context2))
            sheet.write(num, 31, re.findall(r"广东(.+?)例", context1))
            sheet.write(num, 32, re.findall(r"广东(.+?)例", context2))
            sheet.write(num, 33, re.findall(r"河北(.+?)例", context1))
            sheet.write(num, 34, re.findall(r"河北(.+?)例", context2))
            sheet.write(num, 35, re.findall(r"青海(.+?)例", context1))
            sheet.write(num, 36, re.findall(r"青海(.+?)例", context2))
            sheet.write(num, 37, re.findall(r"河南(.+?)例", context1))
            sheet.write(num, 38, re.findall(r"河南(.+?)例", context2))

            sheet.write(num, 39, re.findall(r"天津(.+?)例", context1))
            sheet.write(num, 40, re.findall(r"天津(.+?)例", context2))
            sheet.write(num, 41, re.findall(r"上海(.+?)例", context1))
            sheet.write(num, 42, re.findall(r"上海(.+?)例", context2))
            sheet.write(num, 43, re.findall(r"吉林(.+?)例", context1))
            sheet.write(num, 44, re.findall(r"吉林(.+?)例", context2))
            sheet.write(num, 45, re.findall(r"湖南(.+?)例", context1))
            sheet.write(num, 46, re.findall(r"湖南(.+?)例", context2))
            sheet.write(num, 47, re.findall(r"海南(.+?)例", context1))
            sheet.write(num, 48, re.findall(r"海南(.+?)例", context2))
            sheet.write(num, 49, re.findall(r"重庆(.+?)例", context1))
            sheet.write(num, 50, re.findall(r"重庆(.+?)例", context2))

            sheet.write(num, 51, re.findall(r"云南(.+?)例", context1))
            sheet.write(num, 52, re.findall(r"云南(.+?)例", context2))
            sheet.write(num, 53, re.findall(r"北京(.+?)例", context1))
            sheet.write(num, 54, re.findall(r"北京(.+?)例", context2))
            sheet.write(num, 55, re.findall(r"江苏(.+?)例", context1))
            sheet.write(num, 56, re.findall(r"江苏(.+?)例", context2))
            #特殊处理
            sheet.write(num, 57, re.findall(r"台湾地区(.+?)例", context3,re.S))
            sheet.write(num, 58, re.findall(r"澳门特别行政区(.+?)例", context3,re.S))
            sheet.write(num, 59, re.findall(r"香港特别行政区(.+?)例", context3,re.S))
            #
            sheet.write(num, 60, re.findall(r"山西(.+?)例", context1))
            sheet.write(num, 61, re.findall(r"山西(.+?)例", context2))
            sheet.write(num, 62, re.findall(r"宁夏(.+?)例", context1))
            sheet.write(num, 63, re.findall(r"宁夏(.+?)例", context2))
            sheet.write(num, 64, re.findall(r"浙江(.+?)例", context1))
            sheet.write(num, 65, re.findall(r"浙江(.+?)例", context2))
        except:
            pass




if __name__ == '__main__':
    book = xlwt.Workbook(encoding='utf-8') #创建excel文件
    sheet = book.add_sheet('新冠疫情数据',cell_overwrite_ok=True) #可被覆盖的excel
    sheet.write(0, 0, '报告时间')
    sheet.write(0, 1, '中国大陆新增加确诊病例')
    sheet.write(0, 2, '中国大陆新增无症状感染者')
    sheet.write(0, 3, '西藏新增确诊病例')
    sheet.write(0, 4, '西藏新增无症状感染者')
    sheet.write(0, 5, '贵州新增确诊病例')
    sheet.write(0, 6, '贵州新增无症状感染者')
    sheet.write(0, 7, '黑龙江新增确诊病例')
    sheet.write(0, 8, '黑龙江新增无症状感染者')
    sheet.write(0, 9, '福建新增确诊病例')
    sheet.write(0, 10, '福建新增无症状感染者')
    sheet.write(0, 11, '四川新增确诊病例')
    sheet.write(0, 12, '四川新增无症状感染者')
    sheet.write(0, 13, '江西新增确诊病例')
    sheet.write(0, 14, '江西新增无症状感染者')
    sheet.write(0, 15, '湖北新增确诊病例')
    sheet.write(0, 16, '湖北新增无症状感染者')
    sheet.write(0, 17, '陕西新增确诊病例')
    sheet.write(0, 18, '陕西新增无症状感染者')
    sheet.write(0, 19, '辽宁新增确诊病例')
    sheet.write(0, 20, '辽宁新增无症状感染者')
    sheet.write(0, 21, '山东新增确诊病例')
    sheet.write(0, 22, '山东新增无症状感染者')
    sheet.write(0, 23, '广西新增确诊病例')
    sheet.write(0, 24, '广西新增无症状感染者')
    sheet.write(0, 25, '新疆新增确诊病例')
    sheet.write(0, 26, '新疆新增无症状感染者')
    sheet.write(0, 27, '甘肃新增确诊病例')
    sheet.write(0, 28, '甘肃新增无症状感染者')
    sheet.write(0, 29, '内蒙古新增确诊病例')
    sheet.write(0, 30, '内蒙古新增无症状感染者')
    sheet.write(0, 31, '广东新增确诊病例')
    sheet.write(0, 32, '广东新增无症状感染者')
    sheet.write(0, 33, '河北新增确诊病例')
    sheet.write(0, 34, '河北新增无症状感染者')
    sheet.write(0, 35, '青海新增确诊病例')
    sheet.write(0, 36, '青海新增无症状感染者')
    sheet.write(0, 37, '河南新增确诊病例')
    sheet.write(0, 38, '河南新增无症状感染者')
    sheet.write(0, 39, '天津新增确诊病例')
    sheet.write(0, 40, '天津新增无症状感染者')
    sheet.write(0, 41, '上海新增确诊病例')
    sheet.write(0, 42, '上海新增无症状感染者')
    sheet.write(0, 43, '吉林新增确诊病例')
    sheet.write(0, 44, '吉林新增无症状感染者')
    sheet.write(0, 45, '湖南新增确诊病例')
    sheet.write(0, 46, '湖南新增无症状感染者')
    sheet.write(0, 47, '海南新增确诊病例')
    sheet.write(0, 48, '海南新增无症状感染者')
    sheet.write(0, 49, '重庆新增确诊病例')
    sheet.write(0, 50, '重庆新增无症状感染者')
    sheet.write(0, 51, '云南新增确诊病例')
    sheet.write(0, 52, '云南新增无症状感染者')
    sheet.write(0, 53, '北京新增确诊病例')
    sheet.write(0, 54, '北京新增无症状感染者')
    sheet.write(0, 55, '江苏新增确诊病例')
    sheet.write(0, 56, '江苏新增无症状感染者')
    sheet.write(0, 57, '台湾新增确诊病例')
    sheet.write(0, 58, '澳门新增确诊病例')
    sheet.write(0, 59, '香港新增确诊病例')
    sheet.write(0, 60, '山西新增确诊病例')
    sheet.write(0, 61, '山西新增无症状感染者')
    sheet.write(0, 62, '宁夏新增确诊病例')
    sheet.write(0, 63, '宁夏新增无症状感染者')
    sheet.write(0, 64, '浙江新增确诊病例')
    sheet.write(0, 65, '浙江新增无症状感染者')

    num = 0
    for i in range(1, 18):
        spider(i)
        time.sleep(1)
    print("共爬取{0}篇文章".format(num))
    book.save(u"疫情爬虫.xls")
