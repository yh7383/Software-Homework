# from encodings import unicode_escape
# # -*- coding : utf-8-*-
# coding: unicode_escape
import pandas as pd
import matplotlib.pyplot as plt


plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
# 为了让图标中显示中文标注加入这两行代码

def get_cn_img(data_cn):
    # data_cn = pd.read_csv("9.16全国数据.csv", encoding='gb2312')  # 导入csv文件
    plt.plot(data_cn["日期"], data_cn["当日新增确诊"], color='green', label='当日新增确诊')
    plt.plot(data_cn["日期"], data_cn["当日新增无症状"], color='blue', label='当日新增无症状')
    plt.title('2021.9.26至2022.9.16中国大陆本土疫情数据')
    # 图表的标题
    plt.xlabel('时间')
    # 图表x轴的标注
    plt.ylabel('人数')
    # 图表y轴的标注
    plt.legend()
    plt.show()


def get_fjpro_img(data_pro):
    # plt.plot(data_pro["省份"], data_pro["累计确诊"], color='red', label='累计确诊')
    plt.plot(data_pro["日期"], data_pro["当日新增确诊"], color='green', label='当日新增确诊')
    plt.plot(data_pro["日期"], data_pro["当日新增无症状"], color='blue', label='当日新增无症状')
    plt.title('福建2022.5.10至2022.9.16疫情数据')
    # 图表的标题
    plt.xlabel('日期')
    # 图表x轴的标注
    plt.ylabel('人数')
    # 图表y轴的标注
    plt.legend()
    plt.show()


def main():
    # 一年内中国大陆本土折线图
    data_cn = pd.read_csv("9.16全国数据.csv", encoding='gb2312')  # 导入csv文件
    get_cn_img(data_cn)

    # 中国各省数据折线图
    data_fjpro = pd.read_csv("福建2022.5.10至2022.9.16疫情数据.csv", encoding='gb2312')
    get_fjpro_img(data_fjpro)


if __name__ == "__main__":
    main()
