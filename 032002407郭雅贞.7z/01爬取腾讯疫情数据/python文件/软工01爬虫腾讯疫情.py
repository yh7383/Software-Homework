import requests
import xlwings as xw


# 爬取网站 https://news.qq.com/zt2020/page/feiyan.htm#/

# 中国一年内本土新增
def table_cn(items_china):
    app = xw.App(visible=True, add_book=False)
    wb = app.books.add()
    sht = wb.sheets('Sheet1')  # 建表
    sht.range('A1').value = '更新日期'
    sht.range('B1').value = '当日新增确诊'  # localConfirmadd
    sht.range('C1').value = '当日新增无症状'  # localinfectionadd
    for i in range(365):
        item_dayadds = items_china['chinaDayAddListNew']
        item_dayadd = item_dayadds[i]
        year = item_dayadd['y']
        month, day = item_dayadd['date'].split('.')
        date = year + '-' + month + '-' + day  # 日期减1
        sht.range(f'A{i + 2}').value = date
        cn_localconfirmadd = item_dayadd['localConfirmadd']
        sht.range(f'B{i + 2}').value = cn_localconfirmadd
        cn_localinfectionadd = item_dayadd['localinfectionadd']
        sht.range(f'C{i + 2}').value = cn_localinfectionadd
    # wb.close()
    # app.quit()


# 除港澳台的省份的历史数据
def table_prohis(prohis, app):
    prohis_data=prohis['data']
    wb = app.books.add()  # 打开Excel
    sht = wb.sheets['Sheet1']  # 建表
    sht.range('A1').value = '省份'
    sht.range('B1').value = '日期'  # date
    sht.range('C1').value = '当日新增确诊'  # confirm_add
    sht.range('D1').value = '当日新增无症状'  # wzz_add
    for i in range(130):
        items_prohis = prohis_data[i]
        pro_name = items_prohis['province']  # 省份
        sht.range(f'A{i + 2}').value = pro_name
        year = str(items_prohis['year'])
        month, day = str(items_prohis['date']).split('.')
        date = year + '-' + month + '-' + day
        sht.range(f'B{i + 2}').value = date
        # pro_confirm = pro_data[i]['total']['confirm']  # 累计确诊
        # sht.range(f'C{i + 2}').value = pro_confirm
        pro_confirm_add = items_prohis['confirm_add']  # 当日新增确诊
        sht.range(f'C{i + 2}').value = pro_confirm_add
        pro_wzz = items_prohis['wzz_add']  # 当日新增无症状
        sht.range(f'D{i + 2}').value = pro_wzz
    # print(pro_name)
    # wb.close()
    # app.quit()

# 各省数据
def table_pro(items_pro):
    pro_data = []
    pro_data = items_pro['areaTree'][0]['children']
    j = 0
    # print("港澳台")
    app = xw.App(visible=True, add_book=False)
    wb = app.books.add()  # 打开Excel
    sht = wb.sheets['Sheet1']  # 建表
    sht.range('A1').value = '省份'
    sht.range('B1').value = '更新日期'  # lastUpdateTime
    sht.range('C1').value = '累计确诊'  # confirm
    sht.range('D1').value = '当日新增确诊'  # local_confirm_add
    sht.range('E1').value = '当日新增无症状'  # wzz_add
    for i in range(34):
        pro_name = pro_data[i]['name']  # 省份名字
        if pro_name == '台湾' or pro_name == '香港' or pro_name == '澳门':
            sht.range(f'A{j + 2}').value = pro_name
            pro_date = items_pro['lastUpdateTime'].split(' ')[0]  # 当前日期
            sht.range(f'B{j + 2}').value = pro_date
            pro_confirm = pro_data[i]['total']['confirm']  # 累计确诊
            sht.range(f'C{j + 2}').value = pro_confirm
            pro_confirm_add = pro_data[i]['today']['local_confirm_add']  # 当日新增确诊
            sht.range(f'D{j + 2}').value = pro_confirm_add
            pro_wzz = pro_data[i]['today']['wzz_add']  # 当日新增无症状
            sht.range(f'E{j + 2}').value = pro_wzz
            j = j + 1
        else:
            pro_adcode = pro_data[i]['adcode']  # 省份代码
            prohis_url = "https://api.inews.qq.com/newsqa/v1/query/pubished/daily/list?adCode=" + str(
                pro_adcode) + "&limit=130"   # 获取各省的url
            prohis_response = requests.get(prohis_url)
            prohis_data = prohis_response.json()
            table_prohis(prohis_data, app)   # 导入excel
            # print(prohis_data)


def main():
    # 中国每日本土新增
    cn_url = "https://api.inews.qq.com/newsqa/v1/query/inner/publish/modules/list?modules=chinaDayAddListNew"
    cn_response = requests.get(cn_url)
    cn_data = cn_response.json()['data']
    table_cn(cn_data)  # 导入excel

    # 中国各省数据
    pro_url = "https://api.inews.qq.com/newsqa/v1/query/inner/publish/modules/list?modules=localCityNCOVDataList,diseaseh5Shelf"
    pro_response = requests.get(pro_url)
    allpro_data = pro_response.json()['data']['diseaseh5Shelf']
    table_pro(allpro_data)  # 导入excel


if __name__ == "__main__":
    main()
