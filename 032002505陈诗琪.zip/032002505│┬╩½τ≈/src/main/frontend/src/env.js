module.exports = {
    development:{
        API:"/api",
        MODE:'development',
        NODE_ENV:'production'
    },
    production:{
        API:"",
        MODE:"production",
        NODE_ENC:'production'
    }
}