import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
plt.rcParams['font.sans-serif']=['SimHei']
数据 = pd.read_excel(r"C:\Users\long'er\Desktop\新建文件夹\2022.9.18疫情数据.xlsx")
x=np.array([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33])
y1=数据['新增本土']
y2=数据['新增本土无症状']
bar_width=0.2
#设置x，y轴的标签
plt.xlabel("省份")
plt.ylabel("人数")
plt.legend()
#设置标题
plt.title("2022.9.18疫情数据",fontsize=16,fontweight='bold')
#绘制柱状图
plt.bar(x,y1,bar_width,color='c',alpha=0.5)
plt.bar(x+bar_width,y2,bar_width,color='b',alpha=0.5)
#设置坐标刻度
data=数据['省份']
plt.xticks(x,data)
#添加文本标签
for a,b in zip(x,y1):
    plt.text(a,b,format(b,','),ha='center',va='bottom',fontsize=8)
for a,b in zip(x,y2):
    plt.text(a+bar_width,b,format(b,','),ha='center',va='bottom',fontsize=8)
#设置图例
plt.legend(['新增本土','新增本土无症状'])
plt.show()