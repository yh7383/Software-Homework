import asyncio
import os
import requests
import time
from bs4 import BeautifulSoup
from pyppeteer import launch
import lxml

"""
请求网页源码
def FetchUrl(url):
    return requests.get(url)
    
"""

def sessionGetHtml(session, url):  # 发送带session的网页请求
    Headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3542.0 Safari/537.36'
    }  # 伪装浏览器用的请求头
    try:
        result = session.get(url, headers=Headers)
        result.encoding = result.apparent_encoding
        return result.text
    except Exception as e:
        print(e)
        return ""

async def makeSession(page):
    # 返回一个session,将其内部cookies修改成pypeteer浏览器页面对象中的cookies
    cookies = await page.cookies()
    cookies1 = {}
    for cookie in cookies:
        cookies1[cookie['name']] = cookie['value']
    session = requests.Session()
    session.cookies.update(cookies1)
    return session

async def pyppteer_fetchUrl(url):#将pyppteer操作封装到fetchUrl函数里
    browser = await launch({'headless': False,'dumpio':False, 'autoClose':True})
    page = await browser.newPage()
    await page.evaluateOnNewDocument('() =>{ Object.defineProperties(navigator,'
                                     '{ webdriver:{ get: () => false } }) }')
    await page.setUserAgent(
       'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3542.0 Safari/537.36'
    )
    await page.goto(url)
    await asyncio.sleep(2)
    str = await makeSession(page)
    html = sessionGetHtml(str, url)
    await browser.close()
    return html

def fetchUrl(url):
    return asyncio.get_event_loop().run_until_complete(pyppteer_fetchUrl(url))

#获取每一页疫情通报的链接

def GetPageUrl():
    for Page in range(1,42):
        if Page == 1:
            yield 'http://www.nhc.gov.cn/xcs/yqtb/list_gzbd.shtml'
        else:
            url = 'http://www.nhc.gov.cn/xcs/yqtb/list_gzbd_'+ str(Page) +'.shtml'
            yield url

#获取疫情通报中每日疫情最新情况的链接,标题,日期

def GetTitleUrl(html):
    time.sleep(1)
    soup = BeautifulSoup(html,'lxml')
    TitleList = soup.find('div',attrs = {"class":"list"}).ul.find_all("li")
    for item in TitleList:
        link = "http://www.nhc.gov.cn" + item.a["href"]
        title = item.a["title"]
        date = item.span.text
        yield title , link , date

#获取每篇疫情最新情况中的文本内容
def GetContent(html):
    soup = BeautifulSoup(html,'lxml')
    cnt = soup.find('div',attrs = {"id":"xw_box"}).find_all("p")
    m = ""
    if cnt:
        for item in cnt:
            m += item.text
        return m

    return "ERROR"

#将文本内容保存本地文档
def SaveFile(path,filename,content):
    if os.path.exists(path) == False:
        os.makedirs(path)

    with open(path + filename + ".txt",'w',encoding='utf-8')as f:
        f.write(content)

if"__main__" == __name__:
    for url in GetPageUrl():
        res = fetchUrl(url)

        for title,link,date in GetTitleUrl(res):
            print(title,link)
            year = int(date.split("-")[0])
            mon = int(date.split("-")[1])
            day = int(date.split("-")[2])
            if year <= 2020 and mon <= 1 and day < 21:
                break

            html = fetchUrl(link)
            content = GetContent(html)
            print(content)
            SaveFile("G:/yiqin/datatxt/", title, content)


