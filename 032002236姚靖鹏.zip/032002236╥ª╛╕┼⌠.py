from pydoc import source_synopsis
from tkinter import E
import requests
import xlwt
import asyncio
import re
import lxml
import datetime
from pyecharts import options as opts
from pyecharts.charts import Map
from pyecharts.faker import Faker
from bs4 import BeautifulSoup
from pyppeteer import  launch
from pyppeteer import launcher
from fake_useragent import UserAgent
import json
launcher.DEFAULT_ARGS.remove("--enable-automation")

async def pyppteer_fetchUrl(url):
    browser = await launch({'headless': False,'dumpio':True, 'autoClose':True})
    page = await browser.newPage()
    await page.goto(url)
    await asyncio.wait([page.waitForNavigation()])
    str = await page.content()
    await browser.close()
    return str

def fetchUrl(url):
    return asyncio.get_event_loop().run_until_complete(pyppteer_fetchUrl(url))

def data(str1,str2):  #返回值为列表，列表中各元素为字典，字典中个地址对应各数据
    natmes=[]
    mes3=["(西藏)(.*?)例", "(澳门)(.*?)例", "(青海)(.*?)例", "(台湾)(.*?)例", "(香港)(.*?)例", "(贵州)(.*?)例",
               "(吉林)(.*?)例", "(新疆)(.*?)例", "(宁夏)(.*?)例", "(内蒙古)(.*?)例",
               "(甘肃)(.*?)例", "(天津)(.*?)例", "(山西)(.*?)例", "(辽宁)(.*?)例", "(黑龙江)(.*?)例", "(海南)(.*?)例",
               "(河北)(.*?)例", "(陕西)(.*?)例", "(云南)(.*?)例", "(广西)(.*?)例",
               "(福建)(.*?)例", "(上海)(.*?)例", "(北京)(.*?)例", "(江苏)(.*?)例", "(四川)(.*?)例", "(山东)(.*?)例",
               "(江西)(.*?)例", "(重庆)(.*?)例", "(安徽)(.*?)例", "(湖南)(.*?)例",
               "(河南)(.*?)例", "(广东)(.*?)例", "(浙江)(.*?)例", "(湖北)(.*?)例"]
    for i in mes3:
        element={}
        element["area"]=re.search(i,i).group(1)
        if re.search(i,str1):
            element['nativeRelative']=int(re.search(i,str1).group(2))
        else:
            element['nativeRelative']=0
        natmes.append(element)
    num=0
    for i in mes3:
        if re.search(i,str2):
            natmes[num]['asymptomaticLocalRelative']=int(re.search(i,str2).group(2))
        else:
            natmes[num]['asymptomaticLocalRelative']=0
        num+=1
    return natmes

#主函数
url='http://www.nhc.gov.cn/xcs/yqtb/list_gzbd.shtml'
resp=fetchUrl(url)
soup=BeautifulSoup(resp,'lxml')
url='http://www.nhc.gov.cn/'+soup.find('li').a['href']
html=fetchUrl(url)
soup=BeautifulSoup(html,'lxml')
mes=''
text=soup.find('div',attrs={'id':'xw_box'}).find_all('p')
for i in text:
    mes+=i.text
    mes+='\n'
mes1=re.search("0—24时(.*?)本土病例(.*?)例（(.*?)）",mes)  #昨日新增本土
mes2=re.search("新增无症状感染者(.*?)本土(.*?)例（(.*?)）",mes)  #昨日新增无症状
Cnat=mes1.group(2)  #中国大陆昨日新增本土
Casy=mes2.group(2)  #中国大陆昨日新增无症状
#创建execl表格
excel=xlwt.Workbook(encoding='utf-8')
sheet=excel.add_sheet('疫情数据')
sheet.write(0,0,'省名')
sheet.write(0,1,'新增本土确诊')
sheet.write(0,2,'新增本土无症状')
sheet.write(0,3,'新增确诊')
sheet.write(0,4,'每日热点')  #定义数据类型（写在excel中第一行）
sheet.write(1,0,'中国大陆')  #中国大陆的数据和各省份分开进行数据写入
sheet.write(1,1,Cnat)
sheet.write(1,2,Casy)
line=2
d=data(mes1.group(3),mes2.group(3))
for i in d:
    sheet.write(line, 0, i['area'])
    if((i['area']!='台湾')and(i['area']!='香港')and(i['area']!='澳门')):  #不包括港澳台
        sheet.write(line, 1, i['nativeRelative'])
        sheet.write(line, 2, i['asymptomaticLocalRelative'])
        if(i['nativeRelative']+i['asymptomaticLocalRelative']>=50): #每日热点（若新增本土和新增无症状加起来大于50人则显示疫情较为严重）
            sheet.write(line, 4, '疫情较为严重')
    line+=1

#港澳台的数据从另一个网站上爬取
url = 'https://voice.baidu.com/act/newpneumonia/newpneumonia'
ua = UserAgent()
headers = {
        'User-Agent':ua.random  #UA伪装（随机分配UA）
    }
resp=requests.get(url,headers=headers)
resp.encoding="utf-8"  #解决中文乱码问题
retype=re.findall('"component":\[(.*)\],',resp.text)[0]
js=json.loads(retype)
dict=js['caseList']
line=2
for i in dict:
    if((i['area']=='台湾')or(i['area']=='香港')or(i['area']=='澳门')):
        sheet.write(line, 3, i['confirmedRelative'])
        if(int(i['confirmedRelative'])>=50):
            sheet.write(line, 4, '疫情较为严重')
    line+=1

excel.save('疫情报告.xls')  #保存(创建)excel文档

pro={}
for i in d:
    if((i['area']!='台湾')and(i['area']!='香港')and(i['area']!='澳门')):
        pro[i['area']]=i['nativeRelative']
for i in dict:
     if((i['area']=='台湾')or(i['area']=='香港')or(i['area']=='澳门')):
        pro[i['area']]=i['confirmedRelative']

today=datetime.date.today()
yesterday=today-datetime.timedelta(days=1)  #标题显示昨天的时间
title='今日新增  时间：'
title=title+yesterday.strftime('%Y-%m-%d')
#绘制地图
china_map = {
    Map()
    .add(title, [list(z) for z in zip(pro.keys(), pro.values())], "china")
    .set_global_opts(title_opts=opts.TitleOpts(title="中国地图"),
                     visualmap_opts=opts.VisualMapOpts(min_=0, max_=100))
    .render("今日新增.html")
    }