
from bs4 import BeautifulSoup
from lxml import etree
import requests
import re
import xlwings as xw
import xlsxwriter

if __name__=="__main__":
    str1 = '今日新增境外输入病例:'
    str2 = '今日新增本土病例:'
    str3 = '今日累计新增病例:'
    str4 = '今日新增无症状感染者:'




    headers = {
        'User - Agent': 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/105.0.1343.33',
        'Cookie':'yfx_c_g_u_id_10006654=_ck22091512183215997915178228156; _gscu_2059686908=632182588vvqxg10; sVoELocvxVW0S=5LX07ipZ6ebVdO2JWSSDTnAekJSLESoGTxvr9iogSznuHruU7PIRKEWJImkbQYbPpojNV7k_iYkYnW_MSoDOcJq; yfx_f_l_v_t_10006654=f_t_1663215512592__r_t_1663399099211__v_t_1663403529544__r_c_3; insert_cookie=91349450; security_session_verify=ad037bafe9c3c31f6ce2e76e420e6590; sVoELocvxVW0T=53nKhiCW2PuaqqqDk1jPonGFlIROVMoJAWdcBLPCA9vAxHdPJrcrvDcHmamwElPhlPedGVc7R15y2CEOcR91z3RJUJd4qpApOHj52H_3p01G5kMlrb.0hH2tFuDjbJXVespAAOnrqf7RERjDKfj_N69x65v5E5lL10tySD_ygnHzArJ1i3wjlcjbqnMeEnz72WGnQ8x4X._yfGOM3eA1PygquJsFAQGQhPC1KC8q2ctM2gT_qnetjuw2VWHLjFVFakN9LQyQFafnL0cVoGNozDuTy5tBhnZtMOrrPWb8IgHCOp46nA0ATh.OaKfpxL.6.7'
    }
    app = xw.App(visible=True, add_book=False)
    wb = app.books.add()  # 打开Excel
    sht = wb.sheets['Sheet1']  # 建表
    sht.range('A1').value = '日期'  #对表进行定义
    sht.range('B1').value = '省份'
    sht.range('C1').value = '新增境外输入'
    sht.range('D1').value = '新增本土病例'
    sht.range('E1').value = '新增无症状感染者'
    flag = 0
    for i in range(1,30): #对每页各天的文本进行爬取
        if i==1:
            url = "http://www.nhc.gov.cn/xcs/yqtb/list_gzbd.shtml"
        if i != 1:
            url= "http://www.nhc.gov.cn/xcs/yqtb/list_gzbd_"+str(i)+'.shtml'
        page_text = requests.get(url=url, headers=headers).text
        tree = etree.HTML(page_text)    #通过xpath爬取目的url
        new_url_index_list = tree.xpath('//a/@href')



        for i in range(0, len(new_url_index_list)):  #爬取某一页中一天的文本
            if new_url_index_list[i].startswith("/xcs/yqtb/") and new_url_index_list[i] is not url:
                new_url_text = requests.get(url="http://www.nhc.gov.cn" + str(new_url_index_list[i]),headers=headers).text
                new_url_soup = BeautifulSoup(new_url_text, 'lxml')
                div_tag = new_url_soup.find('div', class_="con", id='xw_box')  #用bs4获取文本详细信息
                content = div_tag.text
                # print(content)
                month = re.search('(.*?)月(.*?)日', content).group(1)   #对文本内需要的信息开始爬取
                day = re.search('(.*?)月(.*?)日', content).group(2)
                date=month + '月' + day + '日'  #获取该页的日期
                sht.range(f'A{flag+i}').value= date
                newinc = re.search('新增确诊病例(.*?)例', content).group(1)  # 新增病例
                td_abroad_num = re.search('境外输入病例(.*?)例', content).group(1)
                newinc_abroad = re.search('境外输入(.*?)；', content).group(1)  # 境外新增病例
                td_demostic_num = re.search('本土病例(.*?)例', content).group(1)
                newinc_demostic = re.search('本土病例(.*?)。', content).group(1)
                newincwzz = re.search('新增无症状感染者(.*?)。', content).group(1)  # 无症状新增病例
                new_wzz_num = re.search('新增无症状感染者(.*?)例', content).group(1)
                #对各省份进行数据爬取
                newinc_abroad_num = 0;   #境外输入数量
                newinc_demostic_num = 0; #国内新增数量
                newinc_wzz_num = 0       #无症状数量
                sht.range(f'B{flag + i}').value = '福建'
                if re.search('福建(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('福建(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('福建(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('福建(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('福建(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('福建(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '广东'
                if re.search('广东(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('广东(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('广东(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('广东(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('广东(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('广东(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '北京'
                if re.search('北京(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('北京(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('北京(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('北京(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('北京(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('北京(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '上海'
                if re.search('上海(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('上海(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('上海(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('上海(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('上海(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('上海(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '黑龙江'
                if re.search('黑龙江(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('黑龙江(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('黑龙江(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('黑龙江(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('黑龙江(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('黑龙江(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '辽宁'
                if re.search('辽宁(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('辽宁(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('辽宁(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('辽宁(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('辽宁(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('辽宁(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '吉林'
                if re.search('吉林(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('吉林(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('吉林(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('吉林(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('吉林(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('吉林(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '河北'
                if re.search('河北(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('河北(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('河北(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('河北(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('河北(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('河北(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '湖北'
                if re.search('湖北(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('湖北(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('湖北(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('湖北(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('湖北(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('湖北(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '河南'
                if re.search('河南(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('河南(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('河南(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('河南(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('河南(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('河南(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '湖南'
                if re.search('湖南(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('湖南(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('湖南(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('湖南(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('湖南(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('湖南(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '山东'
                if re.search('山东(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('山东(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('山东(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('山东(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('山东(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('山东(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '山西'
                if re.search('山西(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('山西(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('山西(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('山西(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('山西(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('山西(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '陕西'
                if re.search('陕西(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('陕西(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('陕西(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('陕西(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('陕西(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('陕西(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '安徽'
                if re.search('安徽(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('安徽(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('安徽(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('安徽(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('安徽(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('安徽(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '浙江'
                if re.search('浙江(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('浙江(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('浙江(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('浙江(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('浙江(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('浙江(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '江苏'
                if re.search('江苏(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('江苏(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('江苏(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('江苏(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('江苏(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('江苏(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '海南'
                if re.search('海南(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('海南(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('海南(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('海南(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('海南(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('海南(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '四川'
                if re.search('四川(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('四川(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('四川(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('四川(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('四川(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('四川(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '云南'
                if re.search('云南(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('云南(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('云南(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('云南(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('云南(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('云南(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '贵州'
                if re.search('贵州(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('贵州(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('贵州(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('贵州(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('贵州(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('贵州(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '青海'
                if re.search('青海(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('青海(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('青海(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('青海(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('青海(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('青海(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '甘肃'
                if re.search('甘肃(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('甘肃(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('甘肃(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('甘肃(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('甘肃(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('甘肃(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '江西'
                if re.search('江西(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('江西(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('江西(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('江西(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('江西(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('江西(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '内蒙古'
                if re.search('内蒙古(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('内蒙古(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('内蒙古(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('内蒙古(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('内蒙古(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('内蒙古(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '宁夏'
                if re.search('宁夏(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('宁夏(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('宁夏(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('宁夏(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('宁夏(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('宁夏(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '新疆'
                if re.search('新疆(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('新疆(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('新疆(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('新疆(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('新疆(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('新疆(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '西藏'
                if re.search('西藏(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('西藏(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('西藏(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('西藏(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('西藏(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('西藏(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '广西'
                if re.search('广西(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('广西(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('广西(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('广西(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('广西(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('广西(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '天津'
                if re.search('天津(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('天津(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('天津(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('天津(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('天津(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('天津(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1
                newinc_abroad_num = 0;
                newinc_demostic_num = 0;
                newinc_wzz_num = 0
                sht.range(f'B{flag + i}').value = '重庆'
                if re.search('重庆(\d+)例', newinc_abroad) is not None:
                    newinc_abroad_num = re.search('重庆(\d+)例', newinc_abroad).group(1)
                sht.range(f'C{flag + i}').value = newinc_abroad_num
                if re.search('重庆(\d+)例', newinc_demostic) is not None:
                    newinc_demostic_num = re.search('重庆(\d+)例', newinc_demostic).group(1)
                sht.range(f'D{flag + i}').value = newinc_demostic_num
                if re.search('重庆(\d+)例', newincwzz) is not None:
                    newinc_wzz_num = re.search('重庆(\d+)例', newincwzz).group(1)
                sht.range(f'E{flag + i}').value = newinc_wzz_num
                flag = flag + 1

    wb.save()








