import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.cm as cm

#todo 画图
plt.rcParams["font.sans-serif"] = ['SimHei']  #设置中文
plt.rcParams["axes.unicode_minus"] = False    #解决乱码
def bar(df):

    df1 = df[(df['area']!='台湾')&(df['area']!='澳门')&(df['area']!='香港')]  #条件筛选  三个省的数据不要
    x1=df1['confirmedRelative'].sum()  #confirmedRelative 求和
    x2=df1['asymptomaticRelative'].sum()  # asymptomaticRelative 求和
    p1= plt.bar('确诊人数', x1, label='确诊人数',width=0.35)   #第一个是编写确诊人数  第二个是x1是数据  width是宽
    p2=plt.bar('无症状感染', x2, label='无症状感染',width=0.35)   #第一个是无症状人数  第二个是x2是数据  width是宽
    plt.bar_label(p1,label_type='edge')   #给x1的数值
    plt.bar_label(p2,label_type='edge')   #给x2的数值
    plt.title('中国今日确诊')  #给上面标题
    plt.xlabel('症状')     #下面的标题
    plt.ylabel('感染人数')  #给y轴标题
    # plt.show()  #关闭


def bar_one(df):
    df = df.set_index('area')  #设置索引
    df.columns = ['确诊人数','无症状感染']  #给类型
    ax = df.plot.bar()  #bar柱状图
    plt.title('所有省份今日确诊')
    # plt.show()

def bar_two(df):
    df = df.set_index('area')  # 设置索引
    df = df.drop(['台湾','澳门','香港'])
    df.columns = ['确诊人数', '无症状感染']  # 给类型
    df.plot.bar()  # bar柱状图
    plt.title('所有省份今日确诊')
    plt.show()  #显示图片



if __name__ == '__main__':
    # todo  读表
    ex_path = r'D:\项目\myject\study\demo_one.xlsx'  # ex表保存的绝对路径
    df = pd.read_excel(ex_path, index_col=False)   #固定写法  把ex表路径传进来  关闭索引
    df.drop(['Unnamed: 0', 'confirmed'], axis=1, inplace=True)   #因为读出来会多一个字段 所以把Unnamed字段删除
    bar(df)  #把df传到bar函数里面
    bar_one(df)  #把df传到bar_one函数里面
    bar_two(df)  #把df传到bar_two函数里面