#加载模块

import requests

import re

import json

import csv

import pandas as pd

import matplotlib.pyplot as plt


headers={
        'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.82 Safari/537.36'
        }
#请求地址

url='https://voice.baidu.com/act/newpneumonia/newpneumonia/?from=osari_aladin_banner'



response=requests.get(url=url,headers=headers)  #发送请求

data_html=response.text  #数据解析

json_str=re.findall('"component":\[(.*)\],',data_html)[0]  #【0】转换数据类型从list到str,强大的正则


json_dict=json.loads(json_str)#转换字典


caseList=json_dict['caseList']  #提取json_dict里面的caseList 数据

list_data = []
for case in caseList:
    item = {}
    item['area']=case['area']   #城市
    item['confirmedRelative']=case['confirmedRelative']  #新增
    item['asymptomaticRelative']=case['asymptomaticRelative']  #新增无症状
    item['confirmed']=case['confirmed'] #累计
    if item['asymptomaticRelative'] == '':  #这里港澳台的数据没有  所以判断为引号的话给它添加为0 方便后面分析
        item['asymptomaticRelative'] = 0
    list_data.append(item)  #把item这个字典添加到列表里面  因为pandas需要列表的数据


#把数据保存到ex表  利用pandas
df = pd.DataFrame(list_data)
df.to_excel(excel_writer='demo_one.xlsx', sheet_name='sheet_1')  #保存进ex表
# print(df)  #解开注释就是保存ex表
