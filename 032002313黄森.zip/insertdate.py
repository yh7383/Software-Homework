from asyncore import write
from base64 import encode
from cgi import test
from cmath import exp
from json import load
from mimetypes import init
from posixpath import split
from unittest import expectedFailure
from openpyxl import Workbook,load_workbook
from openpyxl.styles import *
from openpyxl.chart import *
import datesolve1
#该文件实现的是数据的插入的接口


def init_excel(name):#excel初始化
    province={
'北京':1,
'上海':2,
'天津':3,
'重庆':4,
'安徽':5,
'福建':6,
'广东':7,
'广西':8 ,
'贵州':9 ,
'甘肃':10 ,
'海南':11 ,
'河北':12 ,
'河南':13 ,
'黑龙江':14 ,
'湖北':15 ,
'湖南':16 ,
'吉林':17 ,
'江苏':18 ,
'江西':19 ,
'辽宁':20 ,
'内蒙古':21 ,
'宁夏':22 ,
'青海':23 ,
'陕西':24 ,
'山西':25 ,
'山东':26 ,
'四川':27 ,
'西藏':28 ,
'新疆':29 ,
'云南':30 ,
'浙江':31 ,
'总计':32 ,
"台湾":34 ,
"澳门":35 ,
"香港":36
}
    try:
        wb=load_workbook(name)
    except:
        wb=Workbook()
    ws=wb.active
    ws.cell(1,1).value="日期/类型"
    ws.cell(2,1).value="省份"
    for pro in province.keys():
        a=ws.cell(province[pro]+2,1)
        a.value=pro
    wb.save(name)


# 新增确诊，新增无症状
def insert(excel,start_time,now_time,prov,nums,type):#在某个excel文件插入一条数据的接口
    # print("laile")
    province={
'北京':1,
'上海':2,
'天津':3,
'重庆':4,
'安徽':5,
'福建':6,
'广东':7,
'广西':8 ,
'贵州':9 ,
'甘肃':10 ,
'海南':11 ,
'河北':12 ,
'河南':13 ,
'黑龙江':14 ,
'湖北':15 ,
'湖南':16 ,
'吉林':17 ,
'江苏':18 ,
'江西':19 ,
'辽宁':20 ,
'内蒙古':21 ,
'宁夏':22 ,
'青海':23 ,
'陕西':24 ,
'山西':25 ,
'山东':26 ,
'四川':27 ,
'西藏':28 ,
'新疆':29 ,
'云南':30 ,
'浙江':31 ,
'总计':32 ,
"台湾":34 ,
"澳门":35 ,
"香港":36,
"ai确诊":37
}
    days=datesolve1.cal_days(start_time,now_time)
    rows=0
    print(prov)
    try:

        col=province[prov]+2#算出对应的行

        if type==1:
            rows=days*2#算出对应的列
        else :
            rows=days*2+1
        print(col)
        wb=load_workbook(excel)
        ws=wb.active
        a=ws.cell(col,rows)
        a.value=nums
        ws.cell(1,rows).value=now_time
        if(type==1):
            ws.cell(2,rows).value="新增确诊"
        else:
            ws.cell(2,rows).value="新增无症状"
        wb.save(excel)
    except:
        pass
    








