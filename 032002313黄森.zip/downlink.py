from email import header
from bs4 import BeautifulSoup
import re
import urllib.request,urllib.error
import requests
from selenium import webdriver
from selenium.webdriver.common.by import By
import time
from openpyxl import Workbook,load_workbook
from openpyxl.styles import *
from openpyxl.chart import *
import random

#该文件实现将页面链接爬虫到excel表格

driver = webdriver.Firefox(executable_path='C:\geckodriver.exe')
front_url="http://www.nhc.gov.cn/xcs/yqtb/list_gzbd"
back_url=".shtml"
sums=1
excel="links.xlsx"
try:
    wb=load_workbook(excel)
except:
    wb=Workbook()
ws=wb.active


for i in range(1,42):#41页
    url=""
    if i==1:
        url=front_url+back_url
    else :
        url=front_url+"_"+str(i)+back_url
    driver.get(url)
    time.sleep(random.randint(5,10))
    soup = BeautifulSoup(driver.page_source)
    findLink = re.compile(r'<a href="(.*?)" target=')#正则表达式
    for item in soup.find_all('li'):
        item=str(item)
        link=re.findall(findLink,item)[0]
        ws.cell(sums,1).value=link
        sums+=1
    time.sleep(random.randint(7,16))

print(sums)
wb.save(excel)#保存excel


