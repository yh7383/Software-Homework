from flask import Flask, redirect, url_for, request
from flask import render_template
from json import load
from flask import Flask,request
from jinja2 import Markup
from pyecharts.faker import Faker
from pyecharts import options as opts
from pyecharts.charts import Bar,Map
from openpyxl import Workbook,load_workbook
from openpyxl.styles import *
from openpyxl.chart import *
import time

app = Flask(__name__)
def generate_para(num1,num2):
    s=""
    s+=("根据前三天ai预测新增确诊"+str(num1)+"  ")
    s+=("实际新增确诊"+str(num2)+"  ")
    if num2>num1*2:
        s+="疫情一定程度爆发了"
    if num2<num1/2:
        s+="疫情一定程度抑制住了"
    if num2>=num1/2 and num2<=num1*2:
        s+="符合ai预测"
    return s




def map_base(dict1,dict2) -> Map:
    c = (
    Map()
    .add(
        "新增确诊",
        dict1,
        "china",
        label_opts=opts.LabelOpts(is_show=True),
        is_map_symbol_show=False,
    )
    .add(
        "新增无症状",
        dict2,
        "china",
        label_opts=opts.LabelOpts(is_show=True),
        is_map_symbol_show=False,
    )

    .set_global_opts(
        title_opts=opts.TitleOpts(title="当日新增确诊与无症状"),
        visualmap_opts=opts.VisualMapOpts(),
    )    
)
    return c

start_time="2020-1-10"
def cal_days(time_str1,time_str2):#计算两个日期之间的天数
    time1 = time.mktime(time.strptime(time_str1, '%Y-%m-%d'))
    time2 = time.mktime(time.strptime(time_str2, '%Y-%m-%d'))
    days=abs(int(time1-time2))//3600//24
    return days



@app.route('/success/<time>')
def success(time):
    wb=load_workbook("changes.xlsx")
    ws=wb.active
    days=cal_days(start_time,time)
    line=days*2
    dict1=[]
    dict2=[]
    for i in range(3,34):
        # if ws.cell(i,1140).value!=0:
        dict1.append([ws.cell(i,1).value,ws.cell(i,line).value])
        dict2.append([ws.cell(i,1).value,ws.cell(i,line+1).value])
    for i in range(36,39):
        dict1.append([ws.cell(i,1).value,ws.cell(i,line+1).value-ws.cell(i,line-1).value])
        dict2.append([ws.cell(i,1).value,0])
    c=map_base(dict1,dict2)
    return Markup(c.render_embed())
 



@app.route('/login',methods = ['POST', 'GET'])
def login():
   if request.method == 'POST':
      date = request.form['nm']
      return redirect(url_for('success',time = date))
   else:
      date = request.args.get('nm')
      return redirect(url_for('success',time = date))


@app.route('/')
def index():
    return render_template("login.html")

@app.route('/ai',methods = ['POST', 'GET'])
def ai():
    if request.method == 'POST':
      time = request.form['nm']
    else:
      time = request.args.get('nm')
    print(time)
    wb=wb=load_workbook("changes.xlsx")
    ws=wb.active
    days=cal_days("2020-1-10",time)
    line=days*2
    
    return generate_para(ws.cell(39,line).value,ws.cell(34,line).value)

    # return render_template("aii.html")



if __name__ == '__main__':
   app.run(debug = True)