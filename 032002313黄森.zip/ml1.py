from ctypes import sizeof
import imp
from re import X
from tabnanny import check
import numpy as np
import tensorflow as tf
from keras.layers import Dropout,Dense,SimpleRNN,LSTM
import matplotlib.pyplot as plt
import os
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error,mean_absolute_error
from pandas.core.frame import DataFrame
import insertdate
import datesolve1
#ai处理训练新增确诊数据，将ai预测保存下来



def mechine_learning(pre):
    maotai=pd.read_csv('./type1.csv')
    training_set=maotai.iloc[0:,1:2].values
    test_set=maotai.iloc[300:,1:2]    
    sc=MinMaxScaler(feature_range=(0,1))
    training_set_scaled=sc.fit_transform(training_set)
    test_set=sc.transform(test_set)


    x_train=[]
    y_train=[]

    x_test=[]
    y_test=[]

    for i in range(pre,len(training_set_scaled)):
        x_train.append(training_set_scaled[i-pre:i,0])
        y_train.append(training_set_scaled[i,0])

    np.random.seed(7)
    np.random.shuffle(x_train)
    np.random.seed(7)
    np.random.shuffle(y_train)
    tf.random.set_seed(7)

    x_train,y_trian=np.array(x_train),np.array(y_train)
    x_train=np.reshape(x_train,(x_train.shape[0],pre,1))

    x_train2=x_train

    for i in range(pre,len(test_set)):
        x_test.append(test_set[i-pre:i,0])
        y_test.append(test_set[i,0])

    x_test,y_test=np.array(x_test),np.array(y_test)
    x_test=np.reshape(x_test,(x_test.shape[0],pre,1))

    model=tf.keras.Sequential([
        LSTM(150,return_sequences=True),
        Dropout(0.2),
        LSTM(170),
        Dropout(0.2),
        Dense(1)
    ])
    model.compile(optimizer=tf.keras.optimizers.Adam(0.001),
                    loss='mean_squared_error')

    checkpoint_save_path='./checkpoint1/stock.ckpt'
    if os.path.exists(checkpoint_save_path+".index"):
        print('----------load the model--------')
        model.load_weights(checkpoint_save_path)

    cp_callback=tf.keras.callbacks.ModelCheckpoint(
                        filepath=checkpoint_save_path,
                        save_weights_only=True,
                        save_best_only=True,
                        monitor='val_loss'
    )
    

    history=model.fit(x_train,y_trian,batch_size=64,epochs=50,validation_data=(x_test,y_test),validation_freq=1,callbacks=[cp_callback])
    model.summary()
    file=open('./weights1.txt','w')
    for v in model.trainable_variables:
        file.write(str(v.name)+'\n')
        file.write(str(v.shape)+'\n')
        file.write(str(v.numpy())+'\n')
    file.close()
    

    loss=history.history['loss']
    val_loss=history.history['val_loss']

    plt.plot(loss,label="Training loss")
    plt.plot(val_loss,label="Validation Loss")
    plt.title("Training and Validation Loss")
    plt.legend()
    plt.show()

    predicted_stock_price=model.predict(x_test)
    predicted_stock_price=sc.inverse_transform(predicted_stock_price)
    real_stock_price=sc.inverse_transform(test_set[pre:])
    print(predicted_stock_price)
    plt.plot(real_stock_price,color='red',label='real')
    plt.plot(predicted_stock_price,color='blue',label="predict")
    plt.title("prediction")
    plt.xlabel("time")
    plt.ylabel("nums")
    plt.legend()
    plt.show()

    # print("-----")
    # print(predicted_stock_price)
    # print("++++++")
    # print(real_stock_price)

    predicted_all=model.predict(x_train)
    predicted_all=sc.inverse_transform(predicted_all)
    rl=sc.inverse_transform(training_set[pre:])
    # ts=sc.inverse_transform(training_set)
    # print(len(x_train))
    # print(x_train)
    # print(predicted_all)
    plt.plot(rl,color='red',label='real')
    plt.plot(predicted_all,color='blue',label="predict")
    plt.title("prediction")
    plt.xlabel("time")
    plt.ylabel("nums")
    plt.legend()
    plt.show()

    # t=1
    date="2021-09-23"
    # print("-------------------")
    # print(len(predicted_all))
    for i in predicted_all:
        insertdate.insert("changes.xlsx","2020-1-10",date,"ai确诊",i[0],1)
        date=datesolve1.date_plus1(date)





mechine_learning(3)


