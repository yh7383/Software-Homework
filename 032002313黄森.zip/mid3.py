import datesolve1
import insertdate
# import downpage
import openpyxl
from openpyxl import Workbook,load_workbook
from openpyxl.styles import *
from openpyxl.chart import *
#该文件实现的是调用接口实现处理港澳台的段落并插入数据

province={
    "台湾":34,
    "澳门":35,
    "香港":36
}
if __name__=="__main__":
    for i in range(1,370):
        try:
            insertdate.init_excel("changes.xlsx")
            wb1=load_workbook("pages.xlsx")
            ws1=wb1.active
            para=ws1.cell(i,3).value
            thistime=ws1.cell(i,4).value
            print(ws1.cell(i,7).value)
            if ws1.cell(i,7).value!=None:
                continue
            dict=datesolve1.takecare2(para)
            # print(dict)
            for j in dict.keys():
                insertdate.insert("changes.xlsx","2020-1-10",thistime,j,dict[j],2)
            for j in province:
                if j not in dict:
                    insertdate.insert("changes.xlsx","2020-1-10",thistime,j,0,2)
            
            ws1.cell(i,7).value="港澳台已爬"
            print(i)
            print(ws1.cell(i,4).value)
            wb1.save("pages.xlsx")
        except:
            i-=1