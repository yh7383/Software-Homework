# -*- coding:utf-8 -*-
import datetime
import imp
import re
import time 
import openpyxl
#该文件实现的是数据处理部分的接口




def takecare(paragraph):#处理文本的函数,返回省份对应数量的字典
    province={
'北京':1,
'上海':2,
'天津':3,
'重庆':4,
'安徽':5,
'福建':6,
'广东':7,
'广西':8 ,
'贵州':9 ,
'甘肃':10 ,
'海南':11 ,
'河北':12 ,
'河南':13 ,
'黑龙江':14 ,
'湖北':15 ,
'湖南':16 ,
'吉林':17 ,
'江苏':18 ,
'江西':19 ,
'辽宁':20 ,
'内蒙古':21 ,
'宁夏':22 ,
'青海':23 ,
'陕西':24 ,
'山西':25 ,
'山东':26 ,
'四川':27 ,
'西藏':28 ,
'新疆':29 ,
'云南':30 ,
'浙江':31 ,
'总计':32 
}
    
    dict={}
    single_para=paragraph.split('）')
    target_para=''
    # print(single_para)
    for i in single_para:
        if "本土" in i:
            target_para=i+"）"
            break
    
    if target_para==None:
        return dict
    a=re.findall(r'[（](.*?)[）]', target_para)
    try:
        may_sum=0
        try:
            may_sum=re.findall(r'本土病例(.*?)例',paragraph)[0]
        except:
            pass
        if "均" in target_para:
            for prov in province:
                if prov in target_para:
                    dict[prov]=int(may_sum)
                    return dict
        a=a[0]
        sum=0
        if "；" not in a:
            b_1=a.split('，')
        else :
            b_1=a.split('；')
        for i in b_1:
            if "均" in i:
                pass
            province=(re.search(r"\D+",i).group())
            nums=int(re.search(r"\d+",i).group())
            sum+=nums
            if province in dict:
                dict[province]+=nums
            else :
                dict[province]=nums
        
        dict["总计"]=sum
        return dict
    except :
        return dict
def takecare2(paragraph):#处理港澳台的文本数据接口
    dict={}
    single_para=paragraph.split('，')
    for i in single_para:
        if "台湾" in i:
            if (re.search(r"\d+",i).group())!=None:
                nums=int(re.search(r"\d+",i).group())
            else :
                nums=0
            dict["台湾"]=nums
        if "澳门" in i:
            if (re.search(r"\d+",i).group())!=None:
                nums=int(re.search(r"\d+",i).group())
            else :
                nums=0
            dict["澳门"]=nums
        if "香港" in i:
            if (re.search(r"\d+",i).group())!=None:
                nums=int(re.search(r"\d+",i).group())
            else :
                nums=0
            dict["香港"]=nums
    return dict




def cal_days(time_str1,time_str2):#计算两个日期之间的天数
    time1 = time.mktime(time.strptime(time_str1, '%Y-%m-%d'))#转成时间戳
    time2 = time.mktime(time.strptime(time_str2, '%Y-%m-%d'))
    days=abs(int(time1-time2))//3600//24
    return days

    
def date_plus1(time_str1):#输入日期字符串，返回后一天的字符串
    time1 = time.mktime(time.strptime(time_str1, '%Y-%m-%d'))#转成时间戳
    time1+=3600*24
    time2=time.strftime("%Y-%m-%d", time.localtime(time1))
    return time2


    

    








