from csv import excel
from email import header
from bs4 import BeautifulSoup
import re
import urllib.request,urllib.error
import requests
from selenium import webdriver
from selenium.webdriver.common.by import By
import time
from openpyxl import Workbook,load_workbook
from openpyxl.styles import *
from openpyxl.chart import *
import random



# 注意此处添加了chrome_options参数
# option = webdriver.FirefoxOptions()
# option.add_
def download_pages():#爬虫页面的接口
    driver = webdriver.Firefox(executable_path='C:\geckodriver.exe')
    front_url="http://www.nhc.gov.cn"
    excel="pages.xlsx"
    try:
        wb=load_workbook(excel)
    except:
        wb=Workbook()
    ws=wb.active
    linkwb=load_workbook("links.xlsx")
    linkws=linkwb.active
    for i in range(1,1000):
        if linkws.cell(i,1).value==None:
            break
        if linkws.cell(i,2).value!=None:
            continue
        back_url=linkws.cell(i,1).value
        url=front_url+back_url
        driver.get(url)
        time.sleep(random.randint(1,3))
        soup = BeautifulSoup(driver.page_source)
        findlink = re.compile(r'<a href="(.*?)" target=')
        news = driver.find_element(By.CLASS_NAME,"list").text
        news=news.split("\n")
        for item in news:#将满足条件的段落爬虫
            item=str(item)
            if "新增确诊病例" in item:  
                ws.cell(i,1).value=item
            else :
                if "新增无症状感染者" in item:
                    ws.cell(i,2).value=item
            if  "港澳台" in item:
                ws.cell(i,3).value=item
        for time_now in soup.find_all("span"):
            time_now=str(time_now)
            if "发布时间" in time_now:
                use=time_now.split("\n")
                for times in use:
                    if "2" in times:
                        times=times.strip()
                        ws.cell(i,4).value=times
                    
        linkws.cell(i,2).value="已经爬过"#记录已经爬虫过的页面，以免再爬
        wb.save(excel)#保存excel
        linkwb.save("links.xlsx")
        time.sleep(random.randint(1,3))





