# -*- coding:utf-8 -*-

import datesolve1
import insertdate
# import downpage
import openpyxl
from openpyxl import Workbook,load_workbook
from openpyxl.styles import *
from openpyxl.chart import *
#该文件实现的是调用接口实现处理新增无症状的段落并插入数据


province={
'北京':1,
'上海':2,
'天津':3,
'重庆':4,
'安徽':5,
'福建':6,
'广东':7,
'广西':8 ,
'贵州':9 ,
'甘肃':10 ,
'海南':11 ,
'河北':12 ,
'河南':13 ,
'黑龙江':14 ,
'湖北':15 ,
'湖南':16 ,
'吉林':17 ,
'江苏':18 ,
'江西':19 ,
'辽宁':20 ,
'内蒙古':21 ,
'宁夏':22 ,
'青海':23 ,
'陕西':24 ,
'山西':25 ,
'山东':26 ,
'四川':27 ,
'西藏':28 ,
'新疆':29 ,
'云南':30 ,
'浙江':31  
}

if __name__=="__main__":
    for i in range(1,370):
        try:
            insertdate.init_excel("changes.xlsx")
            wb1=load_workbook("pages.xlsx")
            ws1=wb1.active
            para=ws1.cell(i,2).value
            thistime=ws1.cell(i,4).value
            print(ws1.cell(i,6).value)
            if ws1.cell(i,6).value!=None:
                continue
            dict=datesolve1.takecare(para)
            sums=0
            if "总计" not in dict.keys():
                for prov in dict.keys():
                    sums=sums+dict[prov]
                dict["总计"]=sums

            for j in dict.keys():
                insertdate.insert("changes.xlsx","2020-1-10",thistime,j,dict[j],2)
            for j in province:
                if j not in dict:
                    insertdate.insert("changes.xlsx","2020-1-10",thistime,j,0,2)
            
            ws1.cell(i,6).value="无症状确诊已爬"
            print(i)
            print(ws1.cell(i,4).value)
            wb1.save("pages.xlsx")
        except:
            i-=1






    
    
