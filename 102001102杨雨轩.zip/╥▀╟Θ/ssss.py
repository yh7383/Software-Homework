from selenium.webdriver import Firefox
from selenium.webdriver import FirefoxOptions
import time,re
from bs4 import BeautifulSoup
import requests
def getpageurl():
    for page in range(1,2):
      if page ==1:
          yield "http://www.nhc.gov.cn/xcs/yqtb/list_gzbd.shtml"

      else:
        url='http://www.nhc.gov.cn/xcs/yqtb/list_gzbd_'+str(page)+'.shtml'
        yield url

for url in getpageurl():
     soup = BeautifulSoup('<html><body><p>data</p></body></html>', 'lxml')
     option = FirefoxOptions()
     option.add_argument("--headless")  # 隐藏浏览器
     # option.add_argument('--no-sandbox')
     browser = Firefox(executable_path='geckodriver', options=option)
     browser.get(url)
     time.sleep(10)
     data=browser.page_source
     soup=BeautifulSoup(data,'lxml')
     #alls = browser.find_elements_by_css_selector("li a")
     #for i in alls:
        #print(i.get_attribute('href'), i.text)
     url_list= soup.find('div',class_='list').find_all('li')
     alls = browser.find_elements_by_css_selector("li a")
     for i in alls:
         print(i.get_attribute('href'), i.text)  # i.get_attribute('href')是首页所有连接（不打算
     for i in url_list:
         url='http://www.nhc.gov.cn/' + i.find('a')['href']
         #print(url)
         browser.get(url)
         news = browser.page_source
         #print(news)
         bsobj=BeautifulSoup(news,'lxml')
         time.sleep(10)
         cnt=bsobj.find('div',attrs = {"id": "xw_box"}).find_all("p")
         time.sleep(5)
         s=""
         if cnt:
           for  item  in  cnt:
             s += item.text
           print(s)

           # i.get_attribute('href')是首页所有连接（不打算写其他页了）

'''
   for i in alls:
            c=i.get_attribute('href')
            browser.get(c)
            time.sleep(3)
            news = browser.page_source
            print(news)
new_url = browser.find_element_by_css_selector("li a").get_attribute('href')
browser.get(new_url)
time.sleep(3)
news = browser.page_source
    print(news)  # 每页全部信息
'''





        #(file_path, texts)

'''
script = soup.find(id='span style="font-family')
# 3.3 获取中文文本的内容
countrytext = script.string
print(countrytext)
'''
